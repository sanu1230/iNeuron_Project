import re
import pymongo
import pandas as pd
from pprint import pprint
from pymongo import MongoClient, errors
from eligibility import *

def authcheck(data):
    aut_input = []
    aut_id = []
    aut_dob = []
    name_input = []

    for i in data:
        i.lower()
        if "customer_id" in i:
            customer_id = i.replace("my UserID is ", '')
            aut_id.appned(customer_id)
        elif "my first name is" in i:
            nam = i.replace("my first name is ", '')
            nam_input.append([nam])
        elif "date of birth is" in i:
            dob = re.findall('[0-9]+', i)
            aut_dob.append(dob)

    aut_input.append(aut_id[-1])
    aut_input.append(aut_dob)
    aut_input.append(name_input)
    print("inpt -", aut_input)
    return aut_input


def processing(data):
    inpt = authcheck(data)
    customer_id = inpt[1]
    name = inpt[2]
    dob = inpt[3]
    dict = {"Customer_id" : int(customer_id),"First_name" : name,"Date_of_birth" : dob}
    print("input_dict:", dict)
    in_df = pd.DataFrame(dict, index=[0])
    print('input_df: ', in_df)
    return in_df


def main(data):
    input_df = processing(data)
    db_client = MongoClient()
    db = db_client.AIBankbot
    db = db.Personal_Loan_Customers
    res = db.find_one(input_df)
    #res = db.find_one({"Customer_id":userID,"First_name":name,"Date_of_birth":dob})
    pprint(res)
    if res==None:
        return False
    else:
        return True