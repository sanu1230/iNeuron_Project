import pymongo
from pprint import pprint
from pymongo import MongoClient,errors
from eligibility import *


def main(input,name,dob):
    Customer_id = str(input)
    name = (name)
    dob = (dob)
    db_client = MongoClient()
    db = db_client.AIBankbot
    db = db.Personal_Loan_Customers
    res = db.find_one({"Customer_id":Customer_id,"First_name":name,"Date_of_birth":dob})
    #pprint(res)
    if res==None:
        return False
    elif res["Customer_id"] == Customer_id:
        return True
    elif res["First_name"] == name:
        return True
    elif res["Date_of_birth"] == dob:
        return True

if __name__ == "__main__":
    print(main(1000055,"Anish","20-07-1981"))
